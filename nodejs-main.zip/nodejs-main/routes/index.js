const express = require('express');
const ytdl = require('@distube/ytdl-core');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Эндпоинт для скачивания (Стриминг)
app.get('/api/download', async (req, res) => {
    const url = req.query.url;
    if (!ytdl.validateURL(url)) {
        return res.status(400).send('Неверная ссылка');
    }

    try {
        // Получаем информацию для имени файла
        const info = await ytdl.getInfo(url);
        const title = info.videoDetails.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        
        // Заголовки для скачивания как "ASTRAL MP4"
        res.header('Content-Disposition', `attachment; filename="ASTRAL_${title}.mp4"`);
        
        // quality: 'highest' ищет лучший доступный стрим (обычно до 720p без ffmpeg)
        ytdl(url, { filter: 'audioandvideo', quality: 'highest' }).pipe(res);
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка сервера: Возможно, YouTube заблокировал IP.');
    }
});

app.listen(PORT, () => {
    console.log(`🚀 ASTRAL MP4 Server запущен на порту ${PORT}`);
});